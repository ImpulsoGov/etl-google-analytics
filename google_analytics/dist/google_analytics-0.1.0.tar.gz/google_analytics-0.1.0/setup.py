# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

packages = \
['google_analytics',
 'google_analytics.google_analytics_4',
 'google_analytics.google_analytics_4.quickstart',
 'google_analytics.scripts',
 'google_analytics.utilitarios']

package_data = \
{'': ['*']}

install_requires = \
['frozendict>=2.3.4,<3.0.0',
 'google-analytics-data>=0.15.0,<0.16.0',
 'jsonio>=0.1.4,<0.2.0',
 'loguru>=0.6.0,<0.7.0',
 'pandas>=1.5.2,<2.0.0',
 'psycopg2-binary>=2.9.5,<3.0.0',
 'pyarrow>=10.0.1,<11.0.0',
 'pytest>=7.2.0,<8.0.0',
 'python-dotenv>=0.21.0,<0.22.0',
 'pyupgrade>=3.3.1,<4.0.0',
 'sqlalchemy>=1.4.45,<2.0.0',
 'types-psycopg2>=2.9.21.2,<3.0.0.0']

setup_kwargs = {
    'name': 'google-analytics',
    'version': '0.1.0',
    'description': '',
    'long_description': '',
    'author': 'Your Name',
    'author_email': 'you@example.com',
    'maintainer': 'None',
    'maintainer_email': 'None',
    'url': 'None',
    'package_dir': package_dir,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.10,<4.0',
}


setup(**setup_kwargs)
